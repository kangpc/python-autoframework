from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect
from django.contrib import auth
from django.contrib.auth.decorators import login_required


# Create your views here.

# 首页
def index(request):
    return render(request, "index.html")

# 登录处理
def login_action(request):
    # 第一步 判断请求的方法
    if request.method == "POST":
        print("-----------------------")
        # 接收用户输入的用户名、密码（方法要与页面提交的方法一致）
        login_username = request.POST.get("username")
        login_password = request.POST.get("password")
        print("login_username: "+login_username)
        print("login_password: "+login_password)
        #第二步 判空，如果输入的内容有空的，直接提示
        if login_username == "" or login_password == "":
            # key error相当于发送给客户端的变量，变量对应的值就是后面的value
            return render(request, "index.html", {"error":"username or password null."})
        # 第三步 有输入用户名和密码，那么去数据库查前端传过来的用户名和密码，
        else:
            user = auth.authenticate(username = login_username, password = login_password)
            # 第四步 用户名和密码在数据库有查到，那么进行验证
            if user is not None:
                # 验证登录
                auth.login(request, user)
                #验证通过就重定向到发布会管理页面
                response = HttpResponseRedirect('/event_manage/')
                # 添加浏览器 cookie，10分钟过期
                # response.set_cookie('user',login_username,600)
                # 将session信息记录到浏览器    session的信息是存在服务器端的数据库的
                request.session['user'] = login_username
                # 最后返回发布会管理页面给前端，浏览器进行渲染呈现
                return response
            else:
                return render(request, "index.html", {"error":"Incorrect username or password."})
    else:
        return render(request, "index.html")

# 发布会管理
@login_required    # 关窗，无法直接访问登录成功的页面（在浏览器地址栏直接回车访问event_manage）
def event_manage(request):
    # 读取浏览器 cookie
    # username = request.COOKIES.get('user', '')
    # 读取浏览器 session
    username = request.session.get('user', '')
    return render(request, "event_manage.html", {"user":username})

#退出系统
@login_required
def logout_action(request):
    # 退出并清除掉浏览器保存的用户信息
    auth.logout(request)
    response = HttpResponseRedirect('/index/')
    return response

